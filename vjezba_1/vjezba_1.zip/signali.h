#define K 5 // broj signala

int sig[] = {SIGUSR1, SIGUSR2, SIGTERM, SIGPIPE, SIGINT};
